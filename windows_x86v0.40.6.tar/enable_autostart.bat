@echo off
setlocal

set SCRIPT_DIR=%~dp0

set PS_SCRIPT=%SCRIPT_DIR%enable_autostart.ps1

if "%~1"=="" (
    echo Usage: enable_autostart.bat on^|off
    pause
    exit /b 1
)
powershell -NoLogo -NoProfile -ExecutionPolicy Bypass -Command ^
  "& { . '%PS_SCRIPT%' %* }"

endlocal

